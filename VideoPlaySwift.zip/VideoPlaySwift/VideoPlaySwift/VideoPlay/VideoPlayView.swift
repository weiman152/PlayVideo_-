//
//  VideoPlayView.swift
//  VideoPlaySwift
//
//  Created by iOS on 2018/4/3.
//  Copyright © 2018年 weiman. All rights reserved.
//

import UIKit
import SnapKit

class VideoPlayView: UIView {

    lazy var backgroundView: UIView = {
        $0.backgroundColor = .clear
        return $0
    }( UIView() )
    lazy var titleLabel: UILabel = {
        $0.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        $0.textColor = .white
        $0.textAlignment = .left
        $0.text = ""
        $0.isHidden = true //默认隐藏，当前版本不需要标题
        return $0
    }( UILabel() )
    lazy var controlView: UIView = {
        return $0
    }( UIView() )
    lazy var timeView: UIView = {
        return $0
    }( UIView() )
    lazy var currentTimeLabel: UILabel = {
        $0.font = UIFont.systemFont(ofSize: 12, weight: .regular)
        $0.textColor = .white
        $0.textAlignment = .left
        $0.text = "00:00"
        return $0
    }( UILabel() )
    lazy var totalTimeLabel: UILabel = {
        $0.font = UIFont.systemFont(ofSize: 12, weight: .regular)
        $0.textColor = .white
        $0.textAlignment = .left
        $0.text = "00:00"
        return $0
    }( UILabel() )
    lazy var progress: UIProgressView = {
        $0.progressTintColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.4)
        $0.trackTintColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.2)
        $0.progress = 0
        return $0
    }( UIProgressView() )
    lazy var slider: CustomSlider = {
        $0.setThumbImage(#imageLiteral(resourceName: "sliderThumbImage"), for: .normal)
        $0.height = 5
        $0.maximumTrackTintColor = .clear
        $0.minimumTrackTintColor = UIColor(red: 174/255.0, green: 119/255.0, blue: 255/255.0, alpha: 1.0)
        $0.addTarget(self,
                     action: #selector(sliderTouchDown(slider:)),
                     for: .touchDown)
        $0.addTarget(self,
                     action: #selector(sliderEnd(slider:)),
                     for: .touchUpInside)
        $0.addTarget(self,
                     action: #selector(sliderValueChange(slider:)),
                     for: .valueChanged)
        return $0
    }( CustomSlider() )
    lazy var playAndPauseButton: UIButton = {
        $0.setImage(#imageLiteral(resourceName: "play"), for: .selected)
        $0.setImage(#imageLiteral(resourceName: "pause"), for: .normal)
        $0.addTarget(self,
                     action: #selector(playOrPauseButtonAction(button:)),
                     for: .touchUpInside)
        return $0
    }( UIButton() )
    lazy var showAndHideButton: UIButton = {
        $0.addTarget(self,
                     action: #selector(showOrHideButtonAction(button:)),
                     for: .touchUpInside)
        return $0
    }( UIButton() )
    
    // 播放媒介
    private var mediaPlayer = VideoPlay.shareSingle
    // slider是否正在被手动滑动
    private var isSliderDraging: Bool = false
    // 视频总时间
    private var videoTotalTime: Float = 0.0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setup() {
      
        backgroundColor = .clear
        
        addSubview(backgroundView)
        addSubview(showAndHideButton)
        addSubview(playAndPauseButton)
        backgroundView.addSubview(titleLabel)
        backgroundView.addSubview(timeView)
        backgroundView.addSubview(controlView)
        timeView.addSubview(currentTimeLabel)
        timeView.addSubview(totalTimeLabel)
        controlView.addSubview(progress)
        controlView.addSubview(slider)
        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        backgroundView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.equalToSuperview()
            make.size.equalToSuperview()
        }
        showAndHideButton.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.equalToSuperview()
            make.right.equalToSuperview()
            make.bottom.equalTo(backgroundView.snp.bottom).offset(-49)
        }
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(backgroundView.snp.left).offset(10)
            make.top.equalToSuperview()
            make.right.equalToSuperview()
            make.height.equalTo(44)
        }
        playAndPauseButton.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.width.equalTo(45)
            make.height.equalTo(45)
        }
        currentTimeLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.centerY.equalToSuperview()
        }
        totalTimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(currentTimeLabel.snp.right).offset(0)
            make.right.equalToSuperview()
            make.centerY.equalTo(currentTimeLabel.snp.centerY)
        }
        timeView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalTo(snp.centerY).offset(40)
            make.left.equalTo(currentTimeLabel.snp.left)
            make.right.equalTo(totalTimeLabel.snp.right)
            make.top.equalTo(currentTimeLabel.snp.top)
            make.bottom.equalTo(currentTimeLabel.snp.bottom)
        }
        controlView.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.right.equalToSuperview()
            make.bottom.equalToSuperview()
            make.height.equalTo(49)
        }
        progress.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.centerY.equalTo(controlView.snp.centerY)
            make.right.equalToSuperview()
            make.height.equalTo(4.5)
        }
        slider.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.top.equalToSuperview()
            make.right.equalTo(progress.snp.right)
            make.bottom.equalToSuperview()
        }
    }

}

/// 点击事件相关
extension VideoPlayView {
    
    /// 显示\隐藏 控制按钮事件
    @objc func showOrHideButtonAction(button: UIButton) {

        backgroundView.isHidden ? print("显示") : print("隐藏")
        controlsUI(hide: !backgroundView.isHidden)
        
        //延迟3s执行隐藏
        DispatchQueue.main.asyncAfter(deadline: .now()+3.0) {[weak self] in
            print("----------- 自动隐藏")
            self?.controlsUI(hide: true)
        }
    }
    
    @objc func playOrPauseButtonAction(button: UIButton) {
        button.isSelected = !button.isSelected
        button.isSelected ? pause() : play()
    }
    
    @objc func sliderTouchDown(slider: CustomSlider) {
        isSliderDraging = true
    }
    
    @objc func sliderEnd(slider: CustomSlider) {
        isSliderDraging = false
        let time = slider.value * videoTotalTime
        mediaPlayer.seekTo(time: time)
    }
    
    @objc func sliderValueChange(slider: CustomSlider) {
        let time = slider.value * videoTotalTime
        let timeStr = timeToHMS(time: time)
        currentTimeLabel.text = timeStr
    }
    
    // 隐藏控件
    @objc func controlsUI(hide: Bool) {
        backgroundView.isHidden = hide
        playAndPauseButton.isHidden = hide
    }
}

/// 播放相关
extension VideoPlayView {
    
    /// 带播放控件的视频播放器
    func playVideo(url: String, frame: CGRect) {
        self.frame = frame
        mediaPlayer.delegate = self
        let playerLayer = mediaPlayer.setup(url: url, frame: frame)
        self.layer.insertSublayer(playerLayer, at: 0)
        play()
        DispatchQueue.main.asyncAfter(deadline: .now()+3.0) {[weak self] in
            self?.controlsUI(hide: true)
        }
    }
    
    func play() {
        mediaPlayer.play()
    }
    
    func pause() {
        mediaPlayer.pause()
    }
    
    func remove() {
        mediaPlayer.remove()
        removeFromSuperview()
    }
    
    func set(volume: Float) {
        mediaPlayer.set(volume: volume)
    }
    /// 调到时间点time进行播放
    func seekToTime(time: Float) {
        mediaPlayer.seekTo(time: time)
    }
}

/// 代理相关
extension VideoPlayView: VideoPlayDelegate {
    
    func updateProgress(progress: Float) {
        self.progress.progress = progress
    }
    
    func updateTotalTime(totalTime: Float) {
        videoTotalTime = totalTime
        let time = timeToHMS(time: totalTime)
        totalTimeLabel.text = " / \(time)"
    }
    
    func updatePlayTime(progress: Float, value: Float) {
        if isSliderDraging == true {
            // 如果slider正在被手动拖动的话，暂时不更新正在播放的进度
            return
        }
        slider.value = progress
        currentTimeLabel.text = timeToHMS(time: value)
    }
    
    func playFinish() {
        removeFromSuperview()
    }
}

/// 工具相关
extension VideoPlayView {
    
    /// 把浮点型的秒转成时分秒字符串
    func timeToHMS(time: Float) -> String {
        
        let format = DateFormatter()
        if time / 3600 >= 1 {
            format.dateFormat = "HH:mm:ss"
        } else {
            format.dateFormat = "mm:ss"
        }
        let string = format.string(from: Date(timeIntervalSince1970: TimeInterval(time)))
        return string
    }
}







